#ifndef _STANDALONE2DRENDER_H
#define _STANDALONE2DRENDER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <gpac/compositor.h>

GF_Compositor *SR_NewStandaloneRenderer();

#ifdef __cplusplus
}
#endif

#endif //_STANDALONE2DRENDER_H
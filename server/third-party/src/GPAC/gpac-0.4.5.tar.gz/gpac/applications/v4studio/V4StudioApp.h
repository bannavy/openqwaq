#ifndef _V4STUDIO_APP_H
#define _V4STUDIO_APP_H

class V4StudioApp : public wxApp
{
public:
       virtual bool OnInit();
protected:
private:
};

DECLARE_APP(V4StudioApp)

#endif 

